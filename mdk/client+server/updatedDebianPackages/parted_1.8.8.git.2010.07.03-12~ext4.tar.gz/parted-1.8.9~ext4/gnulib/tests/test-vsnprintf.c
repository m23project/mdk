/* Test of vsnprintf() function.
   Copyright (C) 2007 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.  */

/* Written by Bruno Haible <bruno@clisp.org>, 2007.  */

#include <config.h>

#include <stdio.h>

#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#define ASSERT(expr) \
  do									     \
    {									     \
      if (!(expr))							     \
        {								     \
          fprintf (stderr, "%s:%d: assertion failed\n", __FILE__, __LINE__); \
          abort ();							     \
        }								     \
    }									     \
  while (0)

static int
my_snprintf (char *buf, int size, const char *format, ...)
{
  va_list args;
  int ret;

  va_start (args, format);
  ret = vsnprintf (buf, size, format, args);
  va_end (args);
  return ret;
}

int
main (int argc, char *argv[])
{
  char buf[8];
  int size;
  int retval;

  for (size = 0; size <= 8; size++)
    {
      memcpy (buf, "DEADBEEF", 8);
      retval = my_snprintf (buf, size, "%d", 12345);
      if (size < 6)
	{
#if CHECK_VSNPRINTF_POSIX
	  ASSERT (retval < 0 || retval >= size);
#endif
	  if (size > 0)
	    {
	      ASSERT (memcmp (buf, "12345", size - 1) == 0);
	      ASSERT (buf[size - 1] == '\0' || buf[size - 1] == '0' + size);
	    }
#if !CHECK_VSNPRINTF_POSIX
	  if (size > 0)
#endif
	    ASSERT (memcmp (buf + size, "DEADBEEF" + size, 8 - size) == 0);
	}
      else
	{
	  ASSERT (retval == 5);
	  ASSERT (memcmp (buf, "12345\0EF", 8) == 0);
	}
    }

  return 0;
}
